function people() {
    
}