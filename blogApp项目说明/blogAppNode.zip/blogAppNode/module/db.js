var mongodb = require("mongodb");
var MongoClient = mongodb.MongoClient;

function _connectDB(callback) {
    var url = 'mongodb://localhost:27017/chatApp';
    MongoClient.connect(url,function (err,client) {
        if(err){
            callback(err,null);
            console.log("数据库连接失败");
            return;
        }
        callback(err,client);
    })
}
//插入数据
exports.insertOne = function (collectionName,json,callback) {
    _connectDB(function (err,client) {
        if(err){
            callback(err,null);
            db.close;
            return;
        }
        var db = client.db("chatApp");
        db.collection(collectionName).insertOne(json,function (err,result) {
            callback(err,result);
            db.close;
        })
    })
};
//查找数据
exports.findData = function (collectionName,json,callback) {
    var result = [];//结果数组
    if(arguments.length !=3){
        callback("参数数目应该为3",null);
    }
    _connectDB(function (err,client) {
        if(err){
            callback(err,null);
            return;
            db.close;
        }
        var db = client.db("chatApp");
        var cursor = db.collection(collectionName).find(json);
        cursor.each(function(err,doc){
            if(err){
                callback(err,null);
                return;
            }
            if(doc != null){
                result.push(doc);//导入数组
            }else{
                callback(null,result);
                db.close;
            }
        });

    })
};
exports.updateMany= function (collectionName,jsonCondition,jsonResult,callback) {
    _connectDB(function (err,client) {
        var db = client.db("chatApp");
        db.collection(collectionName).updateMany(jsonCondition,jsonResult,function (err,results) {
            callback(err,results);
            db.close;
        })
    })
};

//删除
exports.deleteMany = function (collectionName,json,callback) {
    _connectDB(function (err,client) {
        var db = client.db("chatApp");
        db.collection(collectionName).deleteMany(json,function (err,results) {
            callback(err,results);
            db.close;
        })
    })
};