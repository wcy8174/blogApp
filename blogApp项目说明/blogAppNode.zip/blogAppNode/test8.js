const express = require("express");
const mongodb = require("mongodb");
const http = require("http");
const db = require("./module/db");
const formidable = require("formidable");

// const bodyParser = require("body-parser");
// const MongoClient = mongodb.MongoClient;
const app = express();

// app.use(bodyParser.urlencoded({extend:false}));
// app.use(bodyParser.json());

//登录
app.post("/login",function (req,res) {
    const form = new formidable.IncomingForm();
    form.parse(req,function (err,fields,files) {
        if(err){
            throw err;
        }
        const name = fields.name;
        const password = parseInt(fields.password);
        console.log(password);
        db.findData("user",{"name":name},function (err,result) {
            if(err){
                console.log("失败");
                res.send("again");
                return;
            }
            if(result[0] == null){
                res.send("invalidName");
            }else if(password != result[0].password){
                console.log(result[0].password);
                res.send("invalidPassword");
            }else{
                res.send("loginSuccess");
            }
        });
    })
});

//注册
app.post("/register",function (req,res) {
    const form = new formidable.IncomingForm();
    form.parse(req,function (err,fields,files) {
        if(err){
            throw err;
            return;
        }
        const name = fields.name;
        const password = fields.password;
        //判断用户名是否存在
        db.findData("user",{"name":name},function (err,result) {
            if(err){
                console.log("失败");
                res.send("again");
                return;
            }
            //用户名已经存在
            if(result[0] != null){
                res.send("invalidName");
            }else {
                //没有这个用户则插入
                db.insertOne("user",{"name":name,"password":password},function (err,results) {
                    if(err){
                        res.send("again");
                        return;
                    }
                    res.send("registerSuccess");
                })
            }
        });
    })
});
//修改密码
app.post("/alterPassword",function (req,res) {
    const form = new formidable.IncomingForm();
    form.parse(req,function (err,fields,files) {
        if(err){
            throw err;
            return;
        }
        const name = fields.name;
        const password = fields.password;
        //判断数据库中，用户名是否存在。存在则找出
        db.findData("user",{"name":name},function (err,result) {
            if(err){
                console.log("失败");
                res.send("again");
                return;
            }
            //数据库中用户不存在（只有人脸，没有数据库注册）
            if(result[0] == null ){
                res.send("invalidName");
            }else {
                //数据库中存在则直接更新密码
                db.updateMany("user",{"name":name},{
                    $set:{"password":password}
                },function (err,results) {
                    if(err){
                        //遇到错误，请重试
                        res.send("again");
                    }
                    res.send("alterSuccess");
                })
            }
        });
    })
});

//删除数据库中用户
app.post("/deleteUser",function (req,res) {
    const form = new formidable.IncomingForm();
    form.parse(req,function (err,fields,files) {
        if(err){
            throw err;
            return;
        }
        const name = fields.name;
        //判断数据库中，用户名是否存在。存在则找出
        db.findData("user",{"name":name},function (err,result) {
            if(err){
                console.log("失败");
                res.send("again");
                return;
            }
            //数据库中用户不存在（只有人脸，没有数据库注册）
            if(result[0] == null ){
                res.send("invalidName");
            }else {
                //数据库中存在则直接删除
                db.deleteMany("user",{"name":name},function (err,results) {
                    if(err){
                        //遇到系统错误，重试
                        res.send("again");
                    }
                    res.send("deleteSuccess");
                })
            }
        });
    })
});

//查找好友
app.post("/findFriends",function (req,res) {
    const form = new formidable.IncomingForm();
    form.parse(req,function (err,fields,files) {
        if(err){
            throw err;
        }
        const name = fields.name;
        db.findData("friendlist",{"name":name},function (err,result) {
            if(err){
                console.log("失败");
                res.send("again");
                return;
            }
            const data = result[0];
            if(data == null){
                res.send("nullFriends");
            }else{
                res.send(data);
            }

        });
    })
});

//添加好友
app.post("/addFriends",function (req,res) {
    const form = new formidable.IncomingForm();
    form.parse(req,function (err,fields,files) {
        if(err){
            throw err;
            return;
        }
        const name = fields.name;
        const friendName = fields.friendName;
        //判断数据库中，用户名是否存在。存在则找出
        db.findData("user",{"name":friendName},function (err,result) {
            if(err){
                console.log("失败");
                res.send("again");
                return;
            }
            //数据库中用户不存在（只有人脸，没有数据库注册）
            if(result[0] == null ){
                res.send("invalidName");
            }else {
                db.findData("friendlist",{"name":name},function (err,results) {
                    if(err){
                        res.send("again");
                        return;
                    }
                    if(results[0] == null){
                        db.insertOne("friendlist",{"name":name,"friends":[friendName]},function (err,results) {
                            if(err){
                                res.send("again");
                                return;
                            }
                            res.send("addSuccess");
                        })
                    }else {
                        db.findData("friendlist",{"name":name,"friends":friendName},function (err,results) {
                            if(err){
                                res.send("again");
                                return;
                            }
                            if(results[0] == null){
                                //没有该好友，数据库中存在则直接更新
                                db.updateMany("friendlist",{"name":name},{
                                    $addToSet: {"friends": friendName }
                                },function (err,results) {
                                    if(err){
                                        //遇到错误，请重试
                                        res.send("again");
                                    }
                                    res.send("addSuccess");
                                })
                            }else{
                                res.send("alreadyExistence")
                            }
                        })
                    }
                })

            }
        });
    })
});

//删除好友
app.post("/deleteFriends",function (req,res) {
    const form = new formidable.IncomingForm();
    form.parse(req,function (err,fields,files) {
        if(err){
            throw err;
            return;
        }
        const name = fields.name;
        const frinedName = fields.friendName;
        //判断数据库中，用户名是否存在。存在则找出
        db.findData("friendlist",{"name":name},function (err,result) {
            if(err){
                console.log("失败");
                res.send("again");
                return;
            }
            //数据库中用户不存在（只有人脸，没有数据库注册）
            if(result[0] == null ){
                res.send("invalidName");
            }else {
                //数据库中存在则直接更新密码
                db.updateMany("friendlist",{"name":name},{
                    $pull: {"friends": frinedName }
                },function (err,results) {
                    if(err){
                        //遇到错误，请重试
                        res.send("again");
                    }
                    res.send("deleteSuccess");
                })
            }
        });
    })
});

//发表博客
app.post("/submitBlog",function (req,res) {
    const form = new formidable.IncomingForm();
    form.parse(req,function (err,fields,files) {
        if (err) {
            throw err;
            return;
        }
        const name = fields.name;
        const time = fields.time;
        const content = fields.content;

        db.findData("blog", {"name": name}, function (err, results) {
            if (err) {
                res.send("again");
                return;
            }
            if (results[0] == null) {
                //调用插入
                db.insertOne("blog", {
                    "name": name,
                    "record": [{"time": time, "content": content}]
                }, function (err, results) {
                    if (err) {
                        res.send("again");
                        return;
                    }
                    res.send("submitSuccess");
                });
            } else {
                //调用更新
                db.updateMany("blog", {"name": name}, {
                    $push: {"record": {"time": time, "content": content}}
                }, function (err, results) {
                    if (err) {
                        res.send("again");
                        return;
                    }
                    res.send("submitSuccess");
                })
            }
        })
    })
});

//删除博客
app.post("/deleteBlog",function (req,res) {
    const form = new formidable.IncomingForm();
    form.parse(req,function (err,fields,files) {
        if (err) {
            throw err;
            return;
        }
        const name = fields.name;
        const time = fields.time;

        db.findData("blog", {"name": name}, function (err, results) {
            if (err) {
                res.send("again");
                return;
            }
            if (results[0] == null) {
                //没有该博客
                res.send("nullBlog");
            } else {
                //调用更新
                db.updateMany("blog", {"name": name}, {
                    $pull: {"record": {"time": time}}
                }, function (err, results) {
                    if (err) {
                        res.send("again");
                        return;
                    }
                    res.send("deleteSuccess");
                })
            }
        })
    })
});

//查找博客
app.post("/findBlog",function (req,res) {
    const form = new formidable.IncomingForm();
    form.parse(req,function (err,fields,files) {
        if(err){
            throw err;
        }
        const name = fields.name;
        //查找所有的博客
        if(name == "all"){
            db.findData("blog",{},function (err,results) {
                if(err){
                    console.log("失败");
                    res.send("again");
                    return;
                }
                res.send(results);
            })
        }else{
            //查找名字是 name 的博客
            db.findData("blog",{"name":name},function (err,results) {
                if(err){
                    console.log("失败");
                    res.send("again");
                    return;
                }
                if(results[0] == null){
                    res.send("nullBlog");
                }else {
                    res.send(results[0]);
                }
            })
        }
    })
});

//修改博客
app.post("/alterBlog",function (req,res) {
    const form = new formidable.IncomingForm();
    form.parse(req,function (err,fields,files) {
        if(err){
            throw err;
        }
        const name = fields.name;
        const time = fields.time;
        const content = fields.content;
        //查找名字是 name 的博客
        db.findData("blog",{"name":name},function (err,results) {
            if(err){
                console.log("失败");
                res.send("again");
                return;
            }
            if(results[0] == null){
                res.send("nullBlog");
            }else {
                //删除旧博客
                db.updateMany("blog", {"name": name}, {
                    $pull: {"record": {"time": time}}
                }, function (err, results) {
                    if (err) {
                        res.send("again");
                        return;
                    }
                    //删除成功后，插入新博客
                    db.updateMany("blog", {"name": name}, {
                        $push: {"record": {"time": time, "content": content}}
                    }, function (err, results) {
                        if (err) {
                            res.send("again");
                            return;
                        }
                        res.send("alterSuccess");
                    })
                });

            }
        })

    })
});

//添加备忘录
app.post("/addMemoRecord",function (req,res) {
    const form = new formidable.IncomingForm();
    form.parse(req,function (err,fields,files) {
        if(err){
            throw err;
            return;
        }
        const name = fields.name;
        const time = fields.time;
        const record = fields.record;

        db.insertOne("memoRecord",{"name":name,"time":time,"record":record},function (err,results) {
            if(err){
                res.send("again");
                return;
            }
            res.send("rememberSuccess");
        })
        })

});


// app.post("/register1",function (req,res) {
//     const name = req.body.name;
//     const password = parseInt(req.body.password);
//     console.log(req.body.toString());
//     console.log(name,password);
//     db.findData("user",{"name":name},function (err,result) {
//         if(err){
//             console.log("失败");
//             res.send("again");
//             return;
//         }
//         //console.log(result);
//         if(result[0] == null){
//             res.send("invalidName");
//         }else if(password != result[0].password){
//             res.send("invalidPassword");
//         }else{
//             res.send("registerSuccess");
//         }
//     })
// });







//启动Express服务器
let server=http.createServer(app);
server.listen(8000,function () {
    console.log("start server at port 8000");
});